package com.sfl.springbootfirstapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFirstApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
