package com.sfl.springbootfirstapi.Controller;

import com.sfl.springbootfirstapi.Entity.Item;
import com.sfl.springbootfirstapi.Repository.ItemRepository;
import com.sfl.springbootfirstapi.Services.ItemServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ItemController {

    @Autowired
    private ItemServices itemService;

    @GetMapping("/api/v1/items")
    public List<Item> getItems(){
        return itemService.getAllItems();
    }

    @GetMapping("/api/v1/items/{id}")
    public Item  getItemById(@PathVariable Long id){
        return itemService.getItemById(id);
    }

    @PostMapping("/api/v1/items")
    public Item createItem(@RequestBody Item item){
        return itemService.saveItem(item);
    }

    @PutMapping("/api/v1/items/{id}")
    public Item updateItem(@PathVariable Long id,@RequestBody Item item){
        return itemService.updateItem(id,item);
    }

}
