package com.sfl.springbootfirstapi.Services;

import com.sfl.springbootfirstapi.Entity.Order;

import java.util.List;

public interface APIServices {
    List<Order> getAllOrders();
    Order getOrderById(int id);
    Order saveOrder(Order order);
    Order updateOrder(int id,Order order);
    String deleteOrderById(int id);
}
