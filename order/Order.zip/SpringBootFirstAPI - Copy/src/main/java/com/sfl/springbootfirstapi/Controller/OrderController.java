package com.sfl.springbootfirstapi.Controller;

import com.sfl.springbootfirstapi.DTO.Product;
import com.sfl.springbootfirstapi.Entity.Order;
import com.sfl.springbootfirstapi.Services.APIServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
public class OrderController {

    @Autowired
    private APIServices service;

    @GetMapping("/api/v1/orders")
    public List<Order> getAllOrders() {
        return service.getAllOrders();
    }

    @GetMapping("/api/v1/orders/{id}")
    public Order getOrderById(@PathVariable int id) {
        return service.getOrderById(id);
    }


    @PostMapping("/api/v1/orders")
    public Order saveOrder(@RequestBody Order order) {
        return service.saveOrder(order);
    }

    @PutMapping("/api/v1/orders/{id}")
    public Order updateOrder(@PathVariable int id,@RequestBody Order order) {
        return service.updateOrder(id,order);
    }

    @DeleteMapping("/api/v1/orders/{id}")
    public String deleteOrder(@PathVariable int id) {
        return service.deleteOrderById(id);
    }

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/api/v1/product/{id}")
    public Product getProductById(@PathVariable int id) {
        return restTemplate.getForObject("http://localhost:8080/api/v1/products/" + id, Product.class);
    }

}


