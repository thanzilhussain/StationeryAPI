package com.sfl.springbootfirstapi.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Product {
    private int id;
    private String productName;
    private double productPrice;
}
