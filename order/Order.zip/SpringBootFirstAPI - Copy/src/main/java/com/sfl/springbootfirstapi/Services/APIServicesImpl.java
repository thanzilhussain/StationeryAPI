package com.sfl.springbootfirstapi.Services;

import com.sfl.springbootfirstapi.DTO.Product;
import com.sfl.springbootfirstapi.Entity.Order;
import com.sfl.springbootfirstapi.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class APIServicesImpl implements APIServices {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public Order getOrderById(int id){
        return orderRepository.findById(id).orElse(null);
    }

    @Override
    public Order saveOrder(Order order) {

        Product product = restTemplate.getForObject(
                "http://localhost:8080/api/v1/products/name/" + order.getProductName(),
                Product.class);

        if (product == null) {
            return null;
        }

        order.setProductId(product.getId());
        order.setProductPrice(product.getProductPrice());
        order.setProductName(product.getProductName());

        order.setTotalPrice(product.getProductPrice() * order.getQuantity());

        return orderRepository.save(order);
    }

    @Override
    public Order updateOrder(int id, Order order) {

        Order existing = orderRepository.findById(id).orElse(null);

        if (existing == null) {
            return null;
        }

        Product product = restTemplate.getForObject(
                "http://localhost:8080/products/name/" + order.getProductName(),
                Product.class);

        if (product == null) {
            return null;
        }

        existing.setCustomerName(order.getCustomerName());

        existing.setProductId(product.getId());
        existing.setProductName(product.getProductName());
        existing.setProductPrice(product.getProductPrice());

        existing.setQuantity(order.getQuantity());

        existing.setTotalPrice(product.getProductPrice() * order.getQuantity());

        return orderRepository.save(existing);
    }

    @Override
    public String deleteOrderById(int id) {
        if (!orderRepository.existsById(id)) {
            return "There is no order with id " + id;
        }
        orderRepository.deleteById(id);
        return "Order with id " + id + " was deleted";
    }
}
