package com.sfl.springbootfirstapi.Services;

import com.sfl.springbootfirstapi.Entity.Item;
import com.sfl.springbootfirstapi.Repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemServices {

    @Autowired
    private ItemRepository itemRepository;

    public Item saveItem(Item item){
        return itemRepository.save(item);
    }
    public Item getItemById(long id){
        return itemRepository.findById(id).orElse(null);
    }

    public List<Item> getAllItems(){
        return itemRepository.findAll();
    }

    public Item updateItem(long id,Item item){
        Item currentItem = itemRepository.getReferenceById(id);
        if (currentItem == null){
            return null;
        }
        currentItem.setName(item.getName());
        currentItem.setStock(item.getStock());
        return  itemRepository.save(currentItem);
    }
}
